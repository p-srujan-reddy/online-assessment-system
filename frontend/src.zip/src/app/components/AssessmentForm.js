// src/app/components/AssessmentForm.js
import React, { useState } from 'react';

const AssessmentForm = ({ onQuestionsGenerated }) => {
  const [topic, setTopic] = useState('');
  const [numQuestions, setNumQuestions] = useState(10);

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Call the backend API to generate questions
    const response = await fetch('/api/generate-questions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ topic, numQuestions }),
    });
    const data = await response.json();
    onQuestionsGenerated(data.questions);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Topic:</label>
        <input
          type="text"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          required
        />
      </div>
      <div>
        <label>Number of Questions:</label>
        <input
          type="number"
          value={numQuestions}
          onChange={(e) => setNumQuestions(e.target.value)}
          required
        />
      </div>
      <button type="submit">Generate Questions</button>
    </form>
  );
};

export default AssessmentForm;
