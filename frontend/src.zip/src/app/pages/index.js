// src/app/pages/index.js
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Home = () => {
  return (
    <div>
      <Header />
      <main>
        <h1>Welcome to the Online Assessment System</h1>
        <p>Generate, distribute, and score assessments easily with our system.</p>
      </main>
      <Footer />
    </div>
  );
};

export default Home;
