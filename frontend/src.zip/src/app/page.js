import React from 'react';
import Layout from './layout';

const Page = () => {
  return (
    <Layout>
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold">Welcome to the Online Assessment System</h1>
        <p className="mt-4">Use the navigation above to get started.</p>
      </div>
    </Layout>
  );
};

export default Page;
